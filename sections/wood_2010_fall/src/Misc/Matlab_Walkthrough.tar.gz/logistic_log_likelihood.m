function log_lik = logistic_log_likelihood(X,Y,beta,alpha)
%function to calculate the log likelihood of X, Y given alpha and beta
%assuming a logistic regression model which we can state as
%P(Y = 1) = exp(alpha + beta * X) / (1 + exp(alpha + beta * X))

assert(size(beta,1) == size(X,2),'beta should be a column vector of approriate length');

if nargin == 4
    lik = (exp(alpha + X * beta) ./ (1 + exp(alpha + X * beta))).^Y ...
        .* (1 ./ (1 + exp(alpha + X * beta))).^(1 - Y);
else
    lik = (exp(X * beta) ./ (1 + exp(X * beta))).^Y ...
        .* (1 ./ (1 + exp(X * beta))).^(1 - Y);
end

log_lik = sum(log(lik));
