function Y = generate_logistic(X,alpha, beta)
%generates Ys coming from a simple logistic regression given covariates Y
%and parameter alpha and beta

assert(size(beta,1) == size(X,2),'beta should be a column vector of approriate length');

p = exp(alpha + X * beta) ./ (1 + exp(alpha + X * beta));
Y = binornd(1,p);
