%Second lecture in two lecture tutorial on how to use matlab for F. Wood's
%courses in Data Mining and Linear Regression
%
%Topics     :   Reading in and writing out data
%               Useful functions (plotting in 3d, fmincon)
%               Using built in random variables
%               Other topics of interest to you


%csvread

help csvread;

%%
%note that csvread only reads numeric data from a csv file.  This has
%limited used, but the easy calling semantics often make it useful.

d = csvread('data/data.csv',1,1);
size(d)

d(1:10,:)

%%
%dlm read is slightly more flexible since we are able to specify the
%delimiter

d = dlmread('data/data.csv',',',1,1);

size(d)

d(1:10,:)

%%
%xlsread will probably work on a windows machine, but i can never get it
%to work well on a mac.  you can feel free to play with this if you care.
d = xlsread('data/data.csv',-1)

%%
%for full read functionality you can use textscan

%here we read in each column, as defined by the delimiter 'comma', as a
%string

fid = fopen('data/data.csv');
d = textscan(fid,'%s %s %s %s %s %s','delimiter', ',');
fclose(fid);

%%
%we can also choose to read in the first row as a header and then read
%everything else with the appropriate format.  Textscan is very flexible
%and is capable of reading things in like a stream so you can check out the
%available options as they become convenient in the help section.

fid = fopen('data/data.csv');
    header = textscan(fid, '%s %s %s %s %s %s' ,1,'delimiter', ',','collectoutput',0);
    d = textscan(fid,'%s %n %n %n %n %n','delimiter',',','collectoutput',0);
fclose(fid);

for i = 1 : size(d,2)
    cmnd = ['v_' header{i}{1} '= d{' num2str(i) '};']
    eval(cmnd)
end

class(v_Date)
v_Date = datenum(v_Date,'dd-mmm-yy');
class(v_Date)

%%
%imread will read images from a file or directly from a url
im = imread('http://www.teslasociety.com/pbust/col5.JPG','jpg');
size(im)
image(im)

%%
%you can write data using similar functions
%csvwrite, dlmwrite, fwrite, fprintf

fid = fopen('data/data.1.csv','w');

fprintf(fid,header{1}{1});
for j = 2 : 6
    fprintf(fid,[',' header{j}{1}]);
end
fprintf(fid,'\n');

fields = {'v_Date','v_Open','v_High','v_Low','v_Close','v_Volume'};

for i = 1:size(v_Date,1)
    fprintf(fid, datestr(v_Date(i),'dd-mmm-yy'));
    for j = 2:6
        val = eval([fields{j} '(i)']);
        fprintf(fid,[',' num2str(val)]);
    end
    fprintf(fid,'\n');
end

fclose(fid);

edit data/data.1.csv
edit data/data.csv

%%
%some random variables worth remembering
m = 1;
std = 10;
normrnd(m, std)

n = 10;
p = .5
binornd(n,p)

%show help for probability distributions

X = (0 : .05 : 10)';
Y = [gampdf(X,1.5,1) gampdf(X,1.5,2) gampdf(X,1.5,3) gampdf(X,1.5,4) gampdf(X,1.5,5)];

h = plot(X,Y);
legend(h, 'beta = 1', 'beta = 2', 'beta = 3', 'beta = 4', 'beta = 5')

%%
%Now moving to plotting in 3 dimensions

%edit logistic_log_likelihood.m

X = normrnd(0,1,1000,1);
alpha = -1.2;
beta = 1.5;
Y = generate_logistic(X,alpha, beta);

%%

log_lik = @(a,b) logistic_log_likelihood(X,Y,b,a);

[A B] = meshgrid(-2:.05:0, .5:.05:3.5);

[r c] = size(A);

L = zeros(r,c);

for i = 1 : r
    for j = 1 : c
        L(i,j) = log_lik(A(i,j),B(i,j));
    end
end

surf(A,B,L)
xlabel('\alpha');
ylabel('\beta');
zlabel('log likelihood');


%%
%how about finding the actual values which minimize that function?

log_lik  = @(params) -1 * logistic_log_likelihood(X,Y,params(2),params(1));

x_0 = [-1,1];

A = zeros(2,2);
b = zeros(1,2);

%fminunc(log_lik,x_0)
fmincon(log_lik, x_0,A,b)

%%
%we can see that this will still work in many dimensions

X = normrnd(0,1,100000,10);
alpha = -1.2;
beta = (1:10)';
Y = generate_logistic(X,alpha, beta);

%%
X_with_intercept = [ones(size(X,1),1) X];

log_lik  = @(params) -1 * logistic_log_likelihood(X_with_intercept,Y,params);

x_0 = zeros(11,1);
fminunc(log_lik,x_0)














