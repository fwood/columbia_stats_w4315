function[m,n] = mean_of_matrix_elements(matr)
%Takes the input matrix and returns the average of its elements
%without calling built in matrix mean functions
%
%@param matr    : matrix of which to find the mean of the elements
%@return m      : mean of elements of matr
matr = matr(:);

%option 1
% s = 0.0;
% num_el = 0;
% for i = 1:size(matr,1)
%     s = s + matr(i);
%     num_el = num_el + 1;
% end
% 
% m = s / num_el;

%option 2
% matr = matr(:);
% s = 0.0;
% num_el = 0;
% for element = matr'
%     s = s + element;
%     num_el = num_el + 1;
% end
% 
% m = s / num_el;

%option 3
m = sum(matr)/ numel(matr);
n = 1;
