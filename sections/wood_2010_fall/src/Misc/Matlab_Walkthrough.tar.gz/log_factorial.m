function[lf] = log_factorial(n)
%returns log(n!) by manually calculating it
%@param n   : number to caluclate log factorial of
%@return lf : log(n!)

assert(n >= 0,'n must be non negative and integer');

if n == 0
    lf = 0.0;
else
    lf = log_factorial(n-1) + log(n);
end