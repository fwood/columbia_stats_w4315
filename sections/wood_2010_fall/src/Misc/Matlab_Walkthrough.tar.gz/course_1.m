%Show the help directory

%%
%the basic data type in matlab is a matrix.
%Defining a matrix
v = [1 4]

v = [1,4]

v = [1;4]

v = [1 2 ; 3 4]

v = [1,4];

%%
%you can also creates matrices withouth excplicitly writing
%out all the elements

e = zeros(3)
e = zeros(3,3)

e = zeros(3,1)
e = zeros(1,3)

e = ones(2,5)

e = [1 : 8]

%%
%if demensions are incorrect you get an error
%e = [0:2:8; 0:5]

%%
%You can concatenate matrices as long as the
%dimensions are appropriate
v = [3,5];
f = [v 1 5 6]

f = [v ; 1 2]

%%
%you can add matrics of same size
a1 = [1 2 3];
a2 = [4 5 6];

a = a1 + a2

%%
%you can also access elements of matrics

%if it is a vector (either row or column) you can use a single index
e = [1 2 4 5 6 3 2];
e(1)
e(5)

%%
%accessing something out of bounds throws an error
e(10)

%%
%if it is a matrix you should use the appropriate number
%of indices
f = [1 2; 3 4];
f(1,1)
f(2,2)

%%
%multiplying by a scalar multiplies the entire matrix
e
f = 7 * e

%%
%if we have two matrices of the right demensions we can
%do matrix operations

t = [1 1 1 1 2 2 2 2];
size(t)

s = [1 2 3 4 5 6 7 8];
size(s)

%we can transpose with '
size(s')

f = t * s'
f = t'* s

%%
%if the dimensions are not correct we get an error
t * s

%%
%vector operations
%we can also do things to each element of a matrix by adding
%a . prior to an operator

b = [3 6; 2 1]

b^2

b.^2

a = eye(2);

b * a
b .* a

%%
%many built in functions are also vectorized

b = [3 6; 2 1]
sin(b)

%%
%example with plotting
x = [0:.1:100];
size(x)
y = sin(x).*x./(1 + cos(x));
plot(x,y,'y',x,y,'go')

who
%whos

%%
%we can also compare numbers using >= > <= < == and ~=
l = 16;
j = 12;

l < j
l > j

if l 
    disp('l is evidently true')
end

%%
%note these comparators are vecotized

b = [1 2 3];
c = [3 2 1];

b == c
b >= c

%%
l = false;
l

if ~l
    disp(['l is evidently not true, l = ' num2str(l)]);
end

%%
%help can be called from the command line

help plot

help mean_of_matrix_elements.m


%%
%creating our own functions

%edit mean_of_matrix_elements.m

b = [1 2 3; 1 2 3];
mean_of_matrix_elements(b)


%%
%can also use while loops if you so choose

%task is to write down all the fibonacci numbers less than or equal to 5000

f = [1 1]
while (f(end) < 5000)
    f = [f (f(end) + f(end-1))];
end

f(1:end-1)

%%
%how about, write a function to tell how many fibanocci numbers
%there are less than a given n

%edit fibonacci_number.m

fibonacci_number(1)
fibonacci_number(2)
fibonacci_number(3)
fibonacci_number(4)
fibonacci_number(5)

fibonacci_number(100000)

%%
%recursion is also a useful programming concept

%task is to write a proram which calculates the log of n!


%edit log_factorial.m
log_factorial(1)

log_factorial(10)
log(factorial(10))

log_factorial(498)
log(factorial(498))

log_factorial(-1)
log_factorial(7.4)
