function[m] = fibonacci_number(n)

assert(n >= 1, 'n must be >= 1');

if n == 1
    m = 0;
else
    last_2 = [0 1];
    m = 1;
    next = 1;
    while next < n
        last_2(1) = last_2(2);
        last_2(2) = next;
        m = m + 1;
        
        next = sum(last_2);
    end
end